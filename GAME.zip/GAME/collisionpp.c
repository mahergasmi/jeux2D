#include "perso.h"
#include "background.h"
Uint32 getpixel(SDL_Surface *surface, int x, int y)
{
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        return *p;
        break;

    case 2:
        return *(Uint16 *)p;
        break;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;
        break;

    case 4:
        return *(Uint32 *)p;
        break;

    default:
        return 0;       /* shouldn't happen, but avoids warnings */
    }
}




int collisionp(SDL_Rect poshero,background bg,SDL_Rect camera)
{
Uint32 noir = SDL_MapRGB(bg.masque->format,0,0,0);
if(getpixel(bg.masque,camera.x+poshero.x,poshero.y+124) == noir)
{
return 1;
}
else
return 0;
}

