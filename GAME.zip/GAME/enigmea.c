#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <SDL/SDL.h>
#include "enigmea.h"
#include <SDL/SDL_image.h>
#include<time.h>
#include"perso.h"
void init_enigme2(enigmea *enig)
{
    enig->image=NULL;
    enig->pos.x=0;
    enig->pos.y=0;
}
void afficher_enigme2(SDL_Surface *ecran,enigmea *enig,int *alea)
{
    int ancienne=*alea;
    char image[30];
    
    do
    {
        *alea=1+random()%4;
    }
    while(*alea==ancienne);
    sprintf(image,"../GAME/enigme2/e%d.png",*alea);
    enig->image=IMG_Load(image);
    SDL_BlitSurface(enig->image,NULL,ecran,&(enig->pos));
    SDL_Flip(ecran);
}
int solution2(int alea)
{
    int solution=0;
    switch(alea)
    {
    case 1:
        solution=3;
        break;
    case 2:
        solution=2;
        break;
    case 3:
        solution=1;
        break;
    case 4:
        solution=1;
        break;
    }
    return solution;
}
int resolution2(int *continuer,int *affiche)
{
    SDL_Event event;
    int r=0;
    (*affiche)=0;
    SDL_PollEvent(&event);
    switch(event.type)
    {
    case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
        case SDLK_a:
            r=1;
	    *affiche=1;
            break;
        case SDLK_z:
            r=2;
	    *affiche=1;
            break;
        case SDLK_e:
            r=3;
            *affiche=1;
            break;
        }
        break;
    }
    return r;
}
void afficher_resultat2(SDL_Surface *ecran,enigmea *enig,int solution,int resolution,perso *p,vie *v)
{
    SDL_Color couleur={0,255,0};
    char ch[10];
    if(solution==resolution)
    {
        enig->image=IMG_Load("../GAME/enigme2/gagner.png");
        SDL_BlitSurface(enig->image,NULL,ecran,&(enig->pos));
        SDL_Flip(ecran);
        p->score+=25;
    }else
    {
        enig->image=IMG_Load("../GAME/enigme2/perdu.png");
        SDL_BlitSurface(enig->image,NULL,ecran,&(enig->pos));
        SDL_Flip(ecran);
        v->num++;
    }
    sprintf(ch,"Score: %d",p->score);
    p->texte=TTF_RenderText_Blended(p->police,ch,couleur);
}
void main_enig(SDL_Surface *ecran,enigmea *enig,perso *p,vie *v)
{
   int alea=0,s,r,continuer=1,affiche=0,tempsActuel=0,tempsPrecedent=0;
   srand(time(NULL));
   afficher_enigme2(ecran,enig,&alea);
   s=solution2(alea);
   continuer=1;
   tempsPrecedent=SDL_GetTicks();
   while(continuer)
     {
        tempsActuel=SDL_GetTicks();
	if(tempsActuel-tempsPrecedent>15000)
 	 {
	    v->num++;
            continuer=0;
	 }
	else
	{
        r=resolution2(&continuer,&affiche);
        if(affiche==1) 
         {
           afficher_resultat2(ecran,enig,s,r,p,v);
           continuer=0;
           SDL_Delay(3000);
             
         }
         
        }
    }
}
void free_enigme2(enigmea *enig)
{
    SDL_FreeSurface(enig->image);
}
