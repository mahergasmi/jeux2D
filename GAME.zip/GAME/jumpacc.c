#include<SDL/SDL.h>
#include<stdio.h>
#include<stdlib.h>
void acc(SDL_Rect *poshero,int d,int *prevd,int g,int *prevg,int *acceleration)
{
if((*prevd)!=d) (*acceleration)=0;
if((*prevg)!=g) (*acceleration)=0;
if(((*prevd)==d)&&(d==1)&&(poshero->x<590))
{
if((*acceleration)<8) (*acceleration)++;
poshero->x+=(*acceleration);
}
else
if(((*prevg)==g)&&(g==1)&&(poshero->x>10))
{
if((*acceleration)<8) (*acceleration)++;
poshero->x-=(*acceleration);
}
(*prevd)=d;
(*prevg)=g;
}

void jumping1(SDL_Rect *poshero,int jump)
{
if((jump==1)&&(poshero->y>150)) {poshero->y-=15;}
if((jump==0)&&(poshero->y<457))
{
poshero->y+=30;
}
}
void jumping2(SDL_Rect *poshero,int jump)
{
if((jump==1)&&(poshero->y>100)) {poshero->y-=15;}
if((jump==0)&&(poshero->y<440))
{
poshero->y+=29;
}
}
