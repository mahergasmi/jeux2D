#include<stdio.h>
#include<stdlib.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>
#include <unistd.h>
#include<time.h>
#include"menu.h"
#include"perso.h"
#include"pers.h"
#include"background.h"
#include"scrolling.h"
#include"ennemi.h"
#include"collisionbb.h"
#include"enigme.h"
#include"enigmea.h"
#include"sousmenu.h"
#include"jumpacc.h"
#include "minimap.h"
#include"object.h"
#include"ia.h"


int main(int argc,char *argv[])
{
   MENU menu;
   mini minimap;
   OBJECT obj;
   Mix_Music *musique;
   background bg;
   perso p;
   perso2 p2;
   vie v;
   vie2 v2;
   ennemi enn;
   enigme enig;
   SDL_Surface *ecran=NULL;
   SDL_Surface *ecranmenu=NULL;
   SDL_Surface *texte_temps=NULL;
   SDL_Surface *gameover=NULL;
   SDL_Rect pos_temps;
   SDL_Rect camera,poshero;
   SDL_Event event;
   SDL_Color couleur={0,255,0};
   int continuer=1,selected,choix=1,d=0,g=0,b=0,a=0,espace=0,h=0,jump,saut=1,ancienne[6],afficher_enig1=0,afficher_enig2=0,temps_joueur=0,temps_menu=0,prevd=0,prevg=0,acceleration=0,ia2=0,score=0,bsave,temps_ancienne_partie=0;
   char temps[20],ch[20];
   SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO);
   TTF_Init();
   pos_temps.x=400;
   pos_temps.y=0;
   ecranmenu=SDL_SetVideoMode(1200,600,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
   MENU_F(&menu,ecranmenu,musique,&selected,&choix);

   bg=initbackground();
   camera=init_camera();
   init_perso(&p,&v);
   load_perso(&p,&v);
   initialiserperso(&p2,&v2);
   init_ennemi(&enn);
   init_obj(&obj);
   init_enigme(&enig,ancienne);
   remplir_fichier("fichier question");
   initmm(&minimap);
   if(selected==3)
{
   load(&enn,&p,&p2,&v,&v2,&camera,&choix,&afficher_enig1,&afficher_enig2,&temps_ancienne_partie);
}

if((choix==1)&&(selected!=6))
{
   
   ecran=SDL_SetVideoMode(1300,600,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
   gameover=IMG_Load("gameover.png");
   temps_menu=SDL_GetTicks();
   SDL_EnableKeyRepeat(10,10);
   while(continuer)
   { 
      if(selected==2) {temps_joueur=SDL_GetTicks()-temps_menu;} else temps_joueur=SDL_GetTicks()-temps_menu+ temps_ancienne_partie;
      sprintf(temps,"Temps: %d:%d",temps_joueur/1000/60,temps_joueur/1000%60);
      texte_temps=TTF_RenderText_Blended(p.police,temps,couleur);

      blit_debout(ecran,&camera,bg.bgimg,&p,&v,&enn,texte_temps,pos_temps,&minimap,&obj);
      SDL_PollEvent(&event);
      switch(event.type)
      {
         case SDL_QUIT:  bsave=sousmenu(ecran);
                         if(bsave==1) save(enn,p,p2,v,v2,camera,choix,afficher_enig1,afficher_enig2,temps_joueur);
                         continuer=0;
                         break;

         case SDL_KEYDOWN:
                             switch(event.key.keysym.sym)
                             {

                                 case SDLK_ESCAPE:  bsave=sousmenu(ecran);
                           			    if(bsave==1) save(enn,p,p2,v,v2,camera,choix,afficher_enig1,afficher_enig2,temps_joueur);
                         			    continuer=0;
                       				    break;
  
			         case SDLK_RIGHT:  
						   d=1;
						   break;
			         case SDLK_LEFT:
						   g=1;
						   break;
				 case SDLK_DOWN:  
                                                   b=1;
						   break;

				 case SDLK_UP:     jump=1;
						   break;

				 case SDLK_a:      a=1;
						   break;

                                 case SDLK_h:      h=1;
						   break;

				 case SDLK_SPACE:  espace=1;
                                                   break;
						   

                             }
                         break;
         case SDL_KEYUP:
                             switch(event.key.keysym.sym)
                             {

			         case SDLK_RIGHT:  
						   d=0;
						   break;
			         case SDLK_LEFT:
						   g=0;
						   break;
				 case SDLK_DOWN:  
                                                   b=0;
						   break;

  				 case SDLK_UP:     jump=0;
                                                   
						   break;

				 case SDLK_a:      a=0;
						   break;

				 case SDLK_h:      h=0;
						   break;

				 case SDLK_SPACE:  espace=0;
                                                   break;
						   

                             }
                         break;
      }
   acc(&p.pos,d,&prevd,g,&prevg,&acceleration);
   jumping1(&p.pos,jump);
   animation_jeu(ecran,&camera,bg.bgimg,&p,&v,d,g,b,a,espace,h,jump,&enn,texte_temps,pos_temps,&minimap,&obj); 
   if((collisionp(p.pos,bg,camera)==1)&&(afficher_enig1==0))   {
                                                                  enigme_alea(ecran,&enig,ancienne,"fichier question",&p.score,&v.num);
                                                                  sprintf(ch,"Score: %d",p.score);
                                                                  p.texte=TTF_RenderText_Blended(p.police,ch,couleur);
				                                  afficher_enig1=1;
                                                                  d=0;g=0;a=0;espace=0;h=0;b=0;jump=0;
                                                               }
   if((collision(p.pos,&enn)==1)&&(p.cache==0)&&(enn.aff==1)) {
                                                                v.num++;    
                                                                p.pos.x=0;
						                if(v.num==5) {
								               SDL_BlitSurface(gameover,NULL,ecran,NULL);
                                                                               SDL_Flip(ecran);
                                                                               continuer=0;
        								       SDL_Delay(5000);
							   		     }
                                                              }

//collision portal

if(afficher_enig2==1)
{
if(p.pos.x<4736-camera.x) {
				poshero.x=p.pos.x+80;
				poshero.y=p.pos.y;
		          }
else {
	poshero.x=p.pos.x;
	poshero.y=p.pos.y;
     }
if(collisionp(poshero,bg,camera)==1) {v.num++;if(p.pos.x<4736-camera.x) p.pos.x-=200;else p.pos.x+=200;}

}
   if((camera.x>=3473)&&(afficher_enig2==0))  {
                                                        init_enigme(&enig,ancienne);
                                                        enigme_alea(ecran,&enig,ancienne,"fichier question",&p.score,&v.num);
                                                        sprintf(ch,"Score: %d",p.score);
                                                        p.texte=TTF_RenderText_Blended(p.police,ch,couleur);
						 	afficher_enig2=1;
                                                        d=0;g=0;a=0;espace=0;h=0;b=0;jump=0;
                                                  } 
   if((camera.x>=5500)&&(ia2==0))  {
                                       ia(argc,argv,&(p.score));
				       ia2=1;
				       if(p.score<0) {p.score=0;v.num++;}
                                       sprintf(ch,"Score: %d",p.score);
                                       p.texte=TTF_RenderText_Blended(p.police,ch,couleur);
                                       d=0;g=0;a=0;espace=0;h=0;b=0;jump=0;
                                   }

   if((camera.x>=5900)&&(enn.mort==1)) {
					  fin_jeu_animation(ecran,&camera,bg.bgimg,&p,&v);
                     	 	          continuer=0;
                                          SDL_Delay(1000);
		  		       }
   if(v.num==5)
   {
      continuer=0;
   }
SDL_Flip(ecran);
   }
}

if((choix==2)&&(selected!=6))
{
   
   ecran=SDL_SetVideoMode(1300,600,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
   gameover=IMG_Load("gameover.png");
   temps_menu=SDL_GetTicks();
   SDL_EnableKeyRepeat(10,10);

   while(continuer)
   {  
      if(selected==2) {temps_joueur=SDL_GetTicks()-temps_menu;} else temps_joueur=SDL_GetTicks()-temps_menu+ temps_ancienne_partie;
      sprintf(temps,"Temps: %d:%d",temps_joueur/1000/60,temps_joueur/1000%60);
      texte_temps=TTF_RenderText_Blended(p2.police,temps,couleur);

      SDL_PollEvent(&event);
      switch(event.type)
      {
         case SDL_QUIT:  bsave=sousmenu(ecran);
                         if(bsave==1) save(enn,p,p2,v,v2,camera,choix,afficher_enig1,afficher_enig2,temps_joueur);
                         continuer=0;
                         break;

         case SDL_KEYDOWN:
                             switch(event.key.keysym.sym)
                             {

                                 case SDLK_ESCAPE:  bsave=sousmenu(ecran);
                           			    if(bsave==1) save(enn,p,p2,v,v2,camera,choix,afficher_enig1,afficher_enig2,temps_joueur);
                         			    continuer=0;
                       				    break;
  
			         case SDLK_RIGHT:  
						   d=1;g=0;
						   break;
			         case SDLK_LEFT:
						   g=1;d=0;
						   break;

				 case SDLK_UP:     jump=1;
                                                   
						   break;

				 case SDLK_a:      a=1;
						   break;

                                 case SDLK_h:      h=1;
						   break;

                             }
                         break;
         case SDL_KEYUP:
                             switch(event.key.keysym.sym)
                             {

			         case SDLK_RIGHT:  
						   d=0;
						   break;
			         case SDLK_LEFT:
						   g=0;
						   break;

				 case SDLK_UP:     jump=0;
						   
						   break;

				 case SDLK_a:      a=0;
						   break;

				 case SDLK_h:      h=0;
						   break;

				 
                             }
                         break;
      }

   acc(&p2.pos,d,&prevd,g,&prevg,&acceleration);
   jumping2(&p2.pos,jump);
   camera=scrolling_speed(camera,d,g,h,p2.pos);
   SDL_BlitSurface(bg.bgimg,&camera,ecran,NULL);
   if(camera.x>=3350) rotozoom_obj(&obj,ecran,&camera);
   animer_perso(d,g,a,ecran,bg.bgimg,camera,&p2,&v2);
   SDL_BlitSurface(texte_temps,NULL,ecran,&pos_temps);
   mini_map2(&minimap,p2.pos,&camera,ecran);
//collision portal
if(afficher_enig2==1)
{
if(p2.pos.x<4736-camera.x) {
				poshero.x=p2.pos.x+75;
				poshero.y=p2.pos.y;
		          }
else {
	poshero.x=p2.pos.x+30;
	poshero.y=p2.pos.y;
     }
if(collisionp(poshero,bg,camera)==1) {v2.num++;if(p2.pos.x<4736-camera.x) p2.pos.x-=200;else p2.pos.x+=200;}

}

   if(((camera.x)>600)||(enn.aff==1)) animer_ennemi(ecran,&enn,p2.pos);
   if((a==1)&&(collision_attaque2(p2.pos,&enn,p2.devant,p2.arriere)==1)&&(enn.mort==0)) {      
								          enn.aff=0;enn.mort=1;p2.score=p2.score+30;
									  sprintf(ch,"Score: %d",p2.score);
                                               			          p2.texte=TTF_RenderText_Blended(p2.police,ch,couleur);
                                                                       }
  if((collisionp(p2.pos,bg,camera)==1)&&(afficher_enig1==0))   {
                                                                  enigme_alea(ecran,&enig,ancienne,"fichier question",&p2.score,&v2.num);
                                                                  sprintf(ch,"Score: %d",p2.score);
                                                                  p2.texte=TTF_RenderText_Blended(p2.police,ch,couleur);
				                                  afficher_enig1=1;d=0;g=0;a=0;h=0;jump=0;
                                                                }

   if((camera.x>=3473)&&(afficher_enig2==0))   {
                                                  init_enigme(&enig,ancienne);
                                                  enigme_alea(ecran,&enig,ancienne,"fichier question",&p2.score,&v2.num);
                                                  sprintf(ch,"Score: %d",p2.score);
                                                  p2.texte=TTF_RenderText_Blended(p2.police,ch,couleur);
				                  afficher_enig2=1;d=0;g=0;a=0;h=0;jump=0;
                                               }
   if((a==0)&&(collision2(p2.pos,&enn)==1)&&(enn.aff==1)) {
                                                                v2.num++;    
                                                                p2.pos.x=0;
						                if(v.num==5) {
								               SDL_BlitSurface(gameover,NULL,ecran,NULL);
                                                                               continuer=0;
        								       SDL_Delay(5000);
							   		     }
                                                          }
   
   if((camera.x>=5500)&&(ia2==0))  {
                    		       ia(argc,argv,&(p2.score));
				       ia2=1;
				       if(p2.score<0) {p2.score=0;v2.num++;}
                                       sprintf(ch,"Score: %d",p2.score);
                                       p2.texte=TTF_RenderText_Blended(p2.police,ch,couleur);
                                       d=0;g=0;a=0;espace=0;h=0;jump=0;
                                   }

   if((camera.x>=5900)&&(enn.mort==1)) {
                     	 	          continuer=0;
                                          SDL_Delay(1000);
		  		       }
   if(v2.num==5)
   {
      continuer=0;
   }
   SDL_Flip(ecran);
   }
}
   free_menu(&menu);
   SDL_FreeSurface(gameover);
   SDL_FreeSurface(texte_temps);
if(selected!=6)
{
   free_perso(&p,&v);
   freefurfaceperso(&p2,&v2);
   free_ennemi(&enn);
   ffree(&enig);
   SDL_FreeSurface(bg.bgimg);
   SDL_FreeSurface(bg.masque);
   free_minimap(&minimap);
   free_obj(&obj);
}
   Mix_CloseAudio(); 
   TTF_Quit();
   SDL_Quit();
return EXIT_SUCCESS;
}
