#ifndef DEFINES_H__
#define DEFINES_H__

// la taille du terrain de jeu
#define MAXX 15 // lignes
#define MAXY 15 // colonne

// terrain de jeu
typedef int TGarray[MAXX][MAXY];

// structure représentant les coordonnées du trait
typedef struct {
  int x, y;
} TCoord;

// pointeur vers la fonction de jeu
typedef TCoord(*TPlayer)(TGarray, int);

// le nombre de points nécessaires pour gagner
#define TOKENS_TO_WIN 5

// liste des symboles possibles - champ vide, croix ou cercle
typedef enum {
  NONA, CROSS, CIRCLE
} TSymbol;

// une liste de conditions pouvant survenir à la fin du jeu
typedef enum {
  EXIT, RESTART,M
} TAction;

// définition de la taille d'une étagère et de la hauteur de la barre d'état
#define FIELD_SIZE  32 // 16
#define STATUSBAR_SIZE 16

// définition de plusieurs couleurs
#define WHITE 0xffffffff
#define RED 0xff0000ff
#define BLACK 0x00000000
#define YELLOW 0xffff00ff
#define PURPLE 0xff00ffff
#define BLUE 0x00ffffff
#define GREEN 0x00ff00ff

#endif
