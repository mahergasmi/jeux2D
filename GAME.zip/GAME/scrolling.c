#include "scrolling.h"
#include <stdbool.h> 
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "perso.h"
SDL_Rect init_camera()
{
   SDL_Rect camera;
   camera.x=0;
   camera.y=0;
   camera.h=600;
   camera.w=1300;
   return camera;
}/*
SDL_Rect scrolling (SDL_Rect camera,int d,int g,SDL_Rect pos)
{

if(d==1){
							
							if ( pos.x>=550)
							{
								
								camera.x+=10;
							}
							
							if (camera.x>=(7368-1400))
							{	
								camera.x=7368-1400;
							}	
        }


if(g==1){
							
							if (pos.x<=20)
							{
							
								camera.x-=10;
							}
							
							if (camera.x<=0)
							{
								camera.x=0;
							
							}
        }

return camera;
}*/
SDL_Rect scrolling_speed(SDL_Rect camera,int d,int g,int h,SDL_Rect pos)
{

if(d==1){
							
							if ( pos.x>=550)
							{
								if(h==1) camera.x+=15;
								if(h==0) camera.x+=8;
							}
							
							if (camera.x>=(7368-1400))
							{	
								camera.x=7368-1400;
							}	
        }


if(g==1){
							
							if (pos.x<=20)
							{
							
								if(h==1) camera.x-=15;
								if(h==0) camera.x-=8;
							}
							
							if (camera.x<=0)
							{
								camera.x=0;
							
							}
        }

return camera;
}
