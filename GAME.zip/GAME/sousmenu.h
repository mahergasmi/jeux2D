#ifndef SOUSMENU_H_
#define SOUSMENU_H_
#include<SDL/SDL.h>
#include "perso.h"
#include "pers.h"
#include "ennemi.h"
typedef struct saves
{
perso p1;
perso2 p2;
SDL_Rect camera;
ennemi enn;
vie v;
vie2 v2;
int choix,enigme1,enigme2,temps;
}saves;
void save(ennemi enn,perso p,perso2 p2,vie v,vie2 v2,SDL_Rect camera,int choix,int enigme1,int enigme2,int temps_joueur);
void load(ennemi *enn,perso *p,perso2 *p2,vie *v,vie2 *v2,SDL_Rect *camera,int *choix,int *enigme1,int *enigme2,int *temps_joueur);
int sousmenu(SDL_Surface *ecran);
#endif 

