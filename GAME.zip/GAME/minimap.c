#include <stdio.h>
#include <stdlib.h> 
#include <SDL/SDL.h> 
#include <SDL/SDL_image.h> 
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include "minimap.h"
void initmm(mini *minimap)
{
minimap->map=NULL;
minimap->curseur=NULL;
minimap->map=IMG_Load("../GAME/mini/minimap.png");
minimap->curseur=IMG_Load("../GAME/mini/curseur.png");
minimap->pos1.x=800;
minimap->pos1.y=0;
minimap->pos2.x=800;
minimap->pos2.y=70;

}

void mini_map(mini *minimap,SDL_Rect poshero,SDL_Rect *camera,SDL_Surface *ecran)
{

minimap->pos2.x=(float)0.068*(poshero.x+camera->x)+800;
minimap->pos2.y=(float)0.15*(poshero.y-467)+70;

SDL_BlitSurface(minimap->map,NULL,ecran,&minimap->pos1);
SDL_BlitSurface(minimap->curseur,NULL,ecran,&minimap->pos2);

}
void mini_map2(mini *minimap,SDL_Rect poshero,SDL_Rect *camera,SDL_Surface *ecran)
{

minimap->pos2.x=(float)0.068*(poshero.x+camera->x)+800;
minimap->pos2.y=(float)0.15*(poshero.y-440)+70;

SDL_BlitSurface(minimap->map,NULL,ecran,&minimap->pos1);
SDL_BlitSurface(minimap->curseur,NULL,ecran,&minimap->pos2);

}


void free_minimap(mini *minimap)
{
SDL_FreeSurface(minimap->map);
SDL_FreeSurface(minimap->curseur);
}
