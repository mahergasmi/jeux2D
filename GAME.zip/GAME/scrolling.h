#ifndef SCROLLING_H
#define SCROLLING_H

#include "background.h"
#include"perso.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

SDL_Rect init_camera();
//SDL_Rect scrolling (SDL_Rect camera,int d,int g,SDL_Rect pos);
SDL_Rect scrolling_speed(SDL_Rect camera,int d,int g,int h,SDL_Rect pos);
#endif
