#ifndef FC_H
#define FC_H

#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include"scrolling.h"
#include"ennemi.h"
#include"collisionbb.h"
#include"minimap.h"
#include"object.h"
void fonctions_jeux1(SDL_Surface *ecran,SDL_Rect *camera,SDL_Surface *fond,ennemi *enn,SDL_Surface *texte_temps,SDL_Rect pos_temps,mini *minimap,SDL_Rect poshero,OBJECT *obj);
void fonctions_jeux2(SDL_Surface *ecran,SDL_Rect *camera,SDL_Surface *fond,int d,int g,int h,int jump,ennemi *enn,SDL_Surface *texte_temps,SDL_Rect pos_temps,mini *minimap,SDL_Rect *poshero,OBJECT *obj);

#endif
