#ifndef PERS_H
#define PERS_H

#include<SDL/SDL.h>
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>

/**
*@struct perso2
*@brief struct for the second hero
*/
typedef struct
{
int devant,arriere,attaque,numd,numg,score,at,atg;
SDL_Rect pos;
SDL_Rect posscore;
SDL_Surface *debout_droite;
SDL_Surface *debout_gauche;
SDL_Surface *marche_droite[5];
SDL_Surface *marche_gauche[5];
SDL_Surface *attaque_droite[11];
SDL_Surface *attaque_gauche[5];
SDL_Surface *texte;
TTF_Font *police;
}perso2;
/**
*@struct vie2
*@brief struct for the life of the second hero
*/
typedef struct
{
int num;
SDL_Surface *vi[5];
SDL_Rect pos;
}vie2;

/**
*@brief to initialize the second hero
*@param the hero
*@param his life
*@return nothing
*/
void initialiserperso(perso2 *perso,vie2 *v);
/**
*@brief to free the second hero
*@param the hero
*@param his life
*@return nothing
*/
void freefurfaceperso(perso2 *perso,vie2 *v);
/**
*@brief to animate the second hero
*@param his life
*@param the hero
*@param his life
*@return nothing
*/
void animer_perso(int d,int q,int e,SDL_Surface *ecran,SDL_Surface *fond,SDL_Rect camera,perso2 *perso,vie2 *v);

#endif
