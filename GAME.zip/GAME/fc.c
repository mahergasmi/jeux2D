#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL_mixer.h>
#include"scrolling.h"
#include"ennemi.h"
#include"collisionbb.h"
#include"minimap.h"
#include"fc.h"
#include"object.h"
#include"jumpacc.h"

void fonctions_jeux1(SDL_Surface *ecran,SDL_Rect *camera,SDL_Surface *fond,ennemi *enn,SDL_Surface *texte_temps,SDL_Rect pos_temps,mini *minimap,SDL_Rect poshero,OBJECT *obj)
{
   SDL_BlitSurface(fond,camera,ecran,NULL);
   SDL_BlitSurface(texte_temps,NULL,ecran,&pos_temps);
   mini_map(minimap,poshero,camera,ecran);
   if(camera->x>=3350) rotozoom_obj(obj,ecran,camera);
   if(((camera->x)>600)||(enn->aff==1)) animer_ennemi(ecran,enn,poshero);
}

void fonctions_jeux2(SDL_Surface *ecran,SDL_Rect *camera,SDL_Surface *fond,int d,int g,int h,int jump,ennemi *enn,SDL_Surface *texte_temps,SDL_Rect pos_temps,mini *minimap,SDL_Rect *poshero,OBJECT *obj)
{
   SDL_Rect cam,pos;
   cam.x=camera->x;
   cam.y=camera->y;
   pos.x=poshero->x;
   pos.y=poshero->y;
   cam=scrolling_speed(cam,d,g,h,pos);
   camera->x=cam.x;
   camera->y=cam.y; 
   SDL_BlitSurface(fond,camera,ecran,NULL);
   jumping1(poshero,jump);
   SDL_BlitSurface(texte_temps,NULL,ecran,&pos_temps);
   mini_map(minimap,pos,camera,ecran);
   if(camera->x>=3350) rotozoom_obj(obj,ecran,camera);
   if(((camera->x)>600)||(enn->aff==1)) animer_ennemi(ecran,enn,pos);
}
