#include <SDL/SDL.h>
#include <SDL/SDL_gfxPrimitives.h>

#include "defines.h"
#include "ai1.h"
#include "ai2.h"
#include "human.h"


/*
* attire les marqueurs sur le terrain de jeu
 */
int drawTurn(SDL_Surface *screen, TCoord c, int player)
{
  if(player == CROSS) {
    lineColor(screen, c.y * FIELD_SIZE + 2, c.x * FIELD_SIZE + 2, c.y * FIELD_SIZE + FIELD_SIZE - 2, c.x * FIELD_SIZE + FIELD_SIZE - 2, 0xff0000ff);
    lineColor(screen, c.y * FIELD_SIZE + FIELD_SIZE - 2, c.x * FIELD_SIZE + 2, c.y * FIELD_SIZE + 2, c.x * FIELD_SIZE + FIELD_SIZE - 2, 0xff0000ff);
  }
  else {
    circleColor(screen, c.y * FIELD_SIZE + FIELD_SIZE / 2, c.x * FIELD_SIZE + FIELD_SIZE / 2, FIELD_SIZE / 2 - 2, 0xffff00ff);
  }
  SDL_UpdateRect(screen, 0,0,0,0);
  return 0;
}

/* 
* dessine la grille du terrain de jeu
 */
int drawBorder(SDL_Surface *screen)
{
  SDL_FillRect(screen, NULL, BLACK);
  for(int i = 1; i < MAXX+1; ++i) {
    hlineColor(screen, 0, MAXY * FIELD_SIZE, i * FIELD_SIZE, 0xffffff50);
  }
  for(int i = 1; i < MAXY; ++i) {
    vlineColor(screen, i * FIELD_SIZE, 0, MAXX * FIELD_SIZE, 0xffffff50);
  }
  SDL_UpdateRect(screen, 0,0,0,0);
  return 0;
}

/*
* barre d'état supprimée
 */
int clearStatusbar(SDL_Surface *screen)
{
  SDL_Rect statusbar = {.x = 0, .y = MAXX * FIELD_SIZE+1, .w = MAXY * FIELD_SIZE, .h = STATUSBAR_SIZE};
  SDL_FillRect(screen, &statusbar, BLACK);
  SDL_UpdateRect(screen, 0,0,0,0);
  return 0;
}

/*
* imprimer du texte dans la barre d'état
 */
int drawIntoStatusbar(SDL_Surface *screen, char* message, int color)
{
  clearStatusbar(screen);
  stringColor(screen, 5, FIELD_SIZE * MAXX + 5, message, color);
  SDL_UpdateRect(screen, 0,0,0,0);
  return 0;
}

/*
* Listes dans la barre d'état qui ont gagné
 */
int drawWin(SDL_Surface *screen, int player,int *score)
{
  if(player == CROSS) {
    drawIntoStatusbar(screen,"X a gagne [q]uit [r]estart [m]enu", RED);
    (*score)+=50;
  }
  else {
    drawIntoStatusbar(screen,"O a gagne [q]uit [r]estart [m]enu", YELLOW);
    (*score)-=50;
  }
  return 0;
}

/*
* liste des menus et paramètres de qui joue
 */
int drawMenu(SDL_Surface *screen, TPlayer* player1, TPlayer* player2)
{
  drawIntoStatusbar(screen, "[F3] X SOLO , [F4] DUO", WHITE);
  SDL_Event event;

  while(1) {
    if(SDL_PollEvent(&event)) {
      if(event.type == SDL_QUIT) {
        return 0;
      }
      if(event.type == SDL_KEYDOWN) {
        switch(event.key.keysym.sym) {
          case SDLK_F1:
            *player1 = ai1;
            *player2 = ai2;
            clearStatusbar(screen);
            //drawIntoStatusbar(screen,"hraji @G(X) a @A(O)", WHITE);
            return 1;
          case SDLK_F2:
            *player1 = ai1;
            *player2 = human;
            clearStatusbar(screen);
            //drawIntoStatusbar(screen,"hrajete proti @G(X)", WHITE);
            return 1;
          case SDLK_F3:
            *player1 = human;
            *player2 = ai2;
            clearStatusbar(screen);
            //drawIntoStatusbar(screen,"hrajete proti @A(O)", WHITE);
            return 1;
          case SDLK_F4:
            *player1 = human;
            *player2 = human;
            clearStatusbar(screen);
            //drawIntoStatusbar(screen,"hraji hraci", WHITE);
            return 1;
          case SDLK_q:
          case SDLK_ESCAPE:
          case SDLK_RETURN:
            return 0;
          default:
            break;
        }
      }
    }
    SDL_Delay(10);
  }
}
