#ifndef GAME_H__
#define GAME_H__

/*
* remplir le terrain de jeu avec un symbole gratuit
 */
void clearBoard(TGarray game_board);

/*
 * vérifier si le coup est gagné
 * s'il gagne, il renvoie 1, sinon 0
 */
int checkWin(TGarray, TCoord);

/*
 * vérifie l'exactitude des coordonnées
 * si les coordonnées données ne sont pas en dehors du champ et que l'étagère est libre, elle renvoie 1, sinon 0
 */
int coordinatesOK(TGarray, TCoord);

/*
 * boucle en fin de partie
 * savoir si le joueur veut rejouer, quitter le programme ou retourner au menu
 */
int endGame(void);

#endif
