#ifndef IA_H
#define IA_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <SDL/SDL.h>

#include "defines.h"
#include "ai1.h"
#include "ai2.h"
#include "human.h"

#include "game.h"
#include "graphics.h"
int ia(int argc, char *argv[],int *score);

#endif
