#ifndef MINIMAP_H
#define MINIMAP_H

#include<SDL/SDL.h>
#include<SDL/SDL_image.h>

typedef struct 
{

SDL_Surface *map;
SDL_Surface *curseur;
SDL_Rect pos1;
SDL_Rect pos2;
}mini;

void initmm(mini *minimap);
void mini_map(mini *minimap,SDL_Rect poshero,SDL_Rect *camera,SDL_Surface *ecran);
void mini_map2(mini *minimap,SDL_Rect poshero,SDL_Rect *camera,SDL_Surface *ecran);
void free_minimap(mini *minimap);
#endif
