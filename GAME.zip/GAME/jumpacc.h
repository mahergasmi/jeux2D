#ifndef JUMPACC_H_
#define JUMPACC_H_
#include<SDL/SDL.h>

void acc(SDL_Rect *poshero,int d,int *prevd,int g,int *prevg,int *acceleration);
void jumping1(SDL_Rect *poshero,int jump);
void jumping2(SDL_Rect *poshero,int jump);
#endif 

