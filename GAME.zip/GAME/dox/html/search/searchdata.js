var indexSectionsWithContent =
{
  0: "bempv",
  1: "bempv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures"
};

