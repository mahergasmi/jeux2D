#ifndef OBJECT_H
#define OBJECT_H

#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
typedef struct 
{
int sens,tempsPrecedent,tempsActuel;
double angle;
double zoom;
SDL_Surface *portal;
SDL_Surface *rotation;
SDL_Rect pos;

}OBJECT;
void init_obj(OBJECT *obj);
void rotozoom_obj(OBJECT *obj,SDL_Surface *ecran,SDL_Rect *camera);
void free_obj(OBJECT *obj);
#endif
