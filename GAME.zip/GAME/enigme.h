#ifndef ENIGME_H_INCLUDED
#define ENIGME_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include"perso.h"

/**
*@struct enigme
*@brief struct for the enigma
*/
typedef struct
{
    SDL_Surface *image;
    SDL_Surface *texte;
    TTF_Font *police;
    SDL_Rect posim,post;
}enigme;
/**
*@brief to initialize the enigma
*@param the new enigma
*@param the last enigma 
*/
void init_enigme(enigme *enig,int ancienne[]);
/**
*@brief to write all the mistery questions in a text file
*@param the name of the file
*/
void remplir_fichier(char fichier_question[]);
/**
*@brief to blit the enigmea
*@param the screen wehere to blit
*@param the new enigma
*@param the last enigma
*@param file name
*@param the enigmea line number in the file 
*/
void afficher_enigme(SDL_Surface *ecran,enigme *enig,int ancienne[],char fichier_question[],int *ligne);
/**
*@brief to get the soluton of the enigma
*@param the line of the enigmea in the file
*/
int solution(int q);
/**
*@brief to get the player response to the enigmea
*@param a param that says if the player did response or not
*/
int resolution(int *affiche);
/**
*@brief to show the result 
*@param the screen
*@param the enigma 
*@param the solution
*@param the resolution 
*@param score of the hero
*@param life of the hero
*/
void afficher_resultat(SDL_Surface *ecran,enigme *enig,int solution,int resolution,int *score,int *vie);
/**
*@brief this function is like the main.c of the enigmea so in the game we can call just this function
*/
void enigme_alea(SDL_Surface *ecran,enigme *enig,int ancienne[],char fichier_question[],int *score,int *vie);
/**
*@brief to free the enigma
*@param the enigma
*/
void ffree(enigme *enig);



#endif // ENIGME_H_INCLUDED
