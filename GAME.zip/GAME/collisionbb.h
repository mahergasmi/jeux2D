#ifndef COLLISIONBB_H_INCLUDED
#define COLLISIONBB_H_INCLUDED
#include"perso.h"
#include"ennemi.h"

int collision_attaque(perso *p,ennemi *enn);
int collision(SDL_Rect poshero,ennemi *enn);

int collision_attaque2(SDL_Rect poshero,ennemi *enn,int prevd,int prevg);
int collision2(SDL_Rect poshero,ennemi *enn);
#endif
