#ifndef HUMAN_H__
#define HUMAN_H__

/*
 * funkce vraci souradnice, kam chce hrac hrat
 * v pripade, ze chce hrac hru ukoncit, vraci souradnice mimo hraci pole
 */
TCoord human(TGarray, int);

#endif
