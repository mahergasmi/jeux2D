#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
#include<SDL/SDL_ttf.h>

/**
*@struct menu
*@brief struct for the menu
*/
typedef struct
{
int num;
SDL_Surface *gif[10];
SDL_Surface *b1,*b2,*b3,*b4,*b5,*choix;
SDL_Surface *bs1,*bs2,*bs3,*bs4,*bs5,*choixs;
SDL_Surface *op1,*op2,*op3,*op4,*boule;
SDL_Surface *c1,*c2,*c3,*c4,*c5,*c6;
SDL_Rect pos1,pos2,pos3,pos4,pos5,pos_choix;
SDL_Rect boulepos;
}MENU;

/**
*@brief to initialize the menu
*@param menu
*/
void init_Menu(MENU *menu);
/**
*@brief to animate the menu background
*@param menu
*@param the screen 
*/
void animation_Menu(MENU *menu,SDL_Surface *ecran);
/**
*@brief to blit the menu buttons selected and not selected
*@param menu
*@param the screen 
*@param selected buttons is a int to know which button is selected by the player
*/
void afficher_boutons_Menu(MENU *menu,SDL_Surface *ecran,int selected_button);
/**
*@brief to blit the options buttons 
*@param menu
*@param the screen 
*@param son_bref_on :a pointer to know if the sound effects are playable or not
*@param son_continu_on :a pointer to know if the music is playable or not
*@param bouton is the name of the sound effect (the click)
*/
void f_options(MENU *menu,SDL_Surface *ecran,int *son_bref_on,int *son_continu_on,Mix_Chunk *bouton);
/**
*@brief to blit the category choix :to choose the hero 
*@param menu
*@param the screen 
*@param son_bref_on :to see if the sounf effects are playable
*@param bouton to play the sound effect when you change the hero
*/
void f_choix(MENU *menu,SDL_Surface *ecran,int *son_bref_on,Mix_Chunk *bouton,int *choix);
/**
*@brief a function that call all the previous functions 
*/
void MENU_F(MENU *menu,SDL_Surface *ecran,Mix_Music *musique,int *selected,int *choix);
/**
*@brief to free the menu
*@param menu
*/
void free_menu(MENU *menu);

#endif
