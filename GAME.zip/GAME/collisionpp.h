#ifndef COLLISIONPP_H
#define COLLISIONPP_H
#include<SDL/SDL.h>
#include "background.h"

Uint32 getpixel(SDL_Surface *surface, int x, int y);
int collisionp(SDL_Rect poshero,background bg,SDL_Rect camera);


#endif 
