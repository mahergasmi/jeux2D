#include<stdio.h>
#include<stdlib.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL_mixer.h>
#include<time.h>
#include"menu.h"
void init_Menu(MENU *menu)
{
int i;
char nom_image[20];
menu->num=0;
for(i=0;i<10;i++)
{
   menu->gif[i]=NULL;
   sprintf(nom_image,"../GAME/menu/gif%d.png",i+1);
   menu->gif[i]=IMG_Load(nom_image);
}
menu->b1=NULL;menu->b2=NULL;menu->b3=NULL;menu->b4=NULL;menu->b5=NULL;menu->bs1=NULL;menu->bs2=NULL;menu->bs3=NULL;menu->bs4=NULL;
menu->bs5=NULL;menu->choix=NULL;menu->choixs=NULL;
menu->op1=NULL;menu->op2=NULL;menu->op3=NULL;menu->op4=NULL;
menu->c1=NULL;menu->c2=NULL;menu->c3=NULL;menu->c4=NULL;menu->c5=NULL;menu->c6=NULL;
menu->boule=NULL;
menu->b1=IMG_Load("../GAME/menu/b1.png");menu->b2=IMG_Load("../GAME/menu/b2.png");menu->b3=IMG_Load("../GAME/menu/b3.png");
menu->b4=IMG_Load("../GAME/menu/b4.png");
menu->b5=IMG_Load("../GAME/menu/b5.png");menu->bs1=IMG_Load("../GAME/menu/bs1.png");menu->bs2=IMG_Load("../GAME/menu/bs2.png");
menu->bs3=IMG_Load("../GAME/menu/bs3.png");
menu->choix=IMG_Load("../GAME/menu/choix.png");menu->choixs=IMG_Load("../GAME/menu/choixs.png");
menu->bs4=IMG_Load("../GAME/menu/bs4.png");
menu->bs5=IMG_Load("../GAME/menu/bs5.png");
menu->op1=IMG_Load("../GAME/menu/onon.png");
menu->op2=IMG_Load("../GAME/menu/offon.png");
menu->op3=IMG_Load("../GAME/menu/onoff.png");
menu->op4=IMG_Load("../GAME/menu/offoff.png");
menu->boule=IMG_Load("../GAME/menu/boule.png");
menu->c1=IMG_Load("../GAME/menu/c1.png");
menu->c2=IMG_Load("../GAME/menu/c2.png");
menu->c3=IMG_Load("../GAME/menu/c3.png");
menu->c4=IMG_Load("../GAME/menu/c4.png");
menu->c5=IMG_Load("../GAME/menu/c5.png");
menu->c6=IMG_Load("../GAME/menu/c6.png");
menu->pos1.x=480;
menu->pos1.y=346;
menu->pos2.x=480;
menu->pos2.y=402;
menu->pos3.x=480;
menu->pos3.y=452;
menu->pos4.x=480;
menu->pos4.y=505;
menu->pos5.x=480;
menu->pos5.y=554;
menu->pos_choix.x=919;
menu->pos_choix.y=114;
menu->boulepos.x=771;
menu->boulepos.y=522;

}

void animation_Menu(MENU *menu,SDL_Surface *ecran)
{
   if(menu->num==10) menu->num=0;
   SDL_BlitSurface(menu->gif[menu->num],NULL,ecran,NULL);
   (menu->num)++;
}

void afficher_boutons_Menu(MENU *menu,SDL_Surface *ecran,int selected_button)
{
   SDL_BlitSurface(menu->b1,NULL,ecran,&(menu->pos1));
   SDL_BlitSurface(menu->b2,NULL,ecran,&(menu->pos2));
   SDL_BlitSurface(menu->b3,NULL,ecran,&(menu->pos3));
   SDL_BlitSurface(menu->b4,NULL,ecran,&(menu->pos4));
   SDL_BlitSurface(menu->b5,NULL,ecran,&(menu->pos5));
   SDL_BlitSurface(menu->choix,NULL,ecran,&(menu->pos_choix));
switch(selected_button)
{
case 2:  SDL_BlitSurface(menu->bs1,NULL,ecran,&(menu->pos1));
         break;
case 3:  SDL_BlitSurface(menu->bs2,NULL,ecran,&(menu->pos2));
         break;
case 4:  SDL_BlitSurface(menu->bs3,NULL,ecran,&(menu->pos3));
         break;
case 5:  SDL_BlitSurface(menu->bs4,NULL,ecran,&(menu->pos4));
         break;
case 6:  SDL_BlitSurface(menu->bs5,NULL,ecran,&(menu->pos5));
         break;
case 1:  SDL_BlitSurface(menu->choixs,NULL,ecran,&(menu->pos_choix));
         break;
}
}

void f_options(MENU *menu,SDL_Surface *ecran,int *son_bref_on,int *son_continu_on,Mix_Chunk *bouton)
{
   int continuer=1;
   int selected_button=2;
   SDL_Event event;
   while(continuer==1)
   { 
    SDL_PollEvent(&event);
    switch(event.type)
    {

       case SDL_KEYDOWN:
                             switch(event.key.keysym.sym)
                             {
				 case SDLK_ESCAPE:  continuer=0;
						  break;

                                 case SDLK_RIGHT: if(menu->boulepos.x<771) menu->boulepos.x+=450*4/128;
						  break;

				 case SDLK_LEFT:  if(menu->boulepos.x>323.5) menu->boulepos.x-=450*4/128;
						  break;           
     
				 case SDLK_DOWN:  selected_button++;
                                                  if(selected_button==3) selected_button=1;
						  break;

				 case SDLK_UP:    selected_button--;
                                                  if(selected_button==0) selected_button=2;
						  break;

				 case SDLK_RETURN: switch(selected_button)
                                                  {
                                                     case 1:   if((*son_continu_on)==1) {
                                                                                        (*son_continu_on)=0;
                                                                                        Mix_PlayChannel(1,bouton,0);
                                                                                        Mix_PauseMusic();
                                                                                        }
                                   				 else {
                                                                      (*son_continu_on)=1;
                                                                      Mix_PlayChannel(1,bouton,0);
                                                                      Mix_ResumeMusic();
                                                                      }
                                                               
							       break;

                                                     case 2:   if((*son_bref_on)==1) {
                                                                                     (*son_bref_on)=0;
                                                                                     Mix_PlayChannel(1,bouton,0);
                                                                                     }
                                  			         else {
                                                                      (*son_bref_on)=1;
                                                                      Mix_PlayChannel(1,bouton,0);
                                                                      }
							       break;
                                                  
                                                  }
                                                  break;

                             }
         break;
       /*case SDL_MOUSEBUTTONDOWN: if((event.button.x>675)&&(event.button.x<748)&&(event.button.y>339)&&(event.button.y<378)) 
                               {
                                  if((*son_continu_on)==1) (*son_continu_on)=0;
                                    else (*son_continu_on)=1;
                               }
                               if((event.button.x>675)&&(event.button.x<748)&&(event.button.y>414)&&(event.button.y<453)) 
                               {
                                  if((*son_bref_on)==1) (*son_bref_on)=0;
                                    else (*son_bref_on)=1;
                               }
                             break;*/
    }
    animation_Menu(menu,ecran);
    if(((*son_bref_on)==1)&&((*son_continu_on)==1))  SDL_BlitSurface(menu->op1,NULL,ecran,NULL); else 
    if(((*son_bref_on)==0)&&((*son_continu_on)==1))  SDL_BlitSurface(menu->op2,NULL,ecran,NULL); else 
    if(((*son_bref_on)==1)&&((*son_continu_on)==0))  SDL_BlitSurface(menu->op3,NULL,ecran,NULL); else 
    if(((*son_bref_on)==0)&&((*son_continu_on)==0))  SDL_BlitSurface(menu->op4,NULL,ecran,NULL);
    SDL_BlitSurface(menu->boule,NULL,ecran,&menu->boulepos);
    SDL_Flip(ecran);
    Mix_VolumeMusic((menu->boulepos.x-323.5)*128/447.5);
    SDL_Delay(100);
   }
}
void f_choix(MENU *menu,SDL_Surface *ecran,int *son_bref_on,Mix_Chunk *bouton,int *choix)
{
   int continuer=1;
   int ligne=1;
   int selected2=1;
   SDL_Event event;
   while(continuer==1)
   { 
    SDL_PollEvent(&event);
    switch(event.type)
    {

       case SDL_KEYDOWN:
                             switch(event.key.keysym.sym)
                             {
				 case SDLK_ESCAPE:  continuer=0;
						  break;

                                 case SDLK_RIGHT: if(ligne==1)
                                                     (*choix)++;
                                                  else selected2++;
                                                  if((*choix)==3) (*choix)=1;
                                                  if(selected2==4) selected2=1;
                                                  if((*son_bref_on)==1) Mix_PlayChannel(1,bouton,0);
						  break;

				 case SDLK_LEFT:  if(ligne==1)
                                                     (*choix)--;
                                                  else selected2--;
                                                  if((*choix)==0) (*choix)=2;
                                                  if(selected2==0) selected2=3;
                                                  if((*son_bref_on)==1) Mix_PlayChannel(1,bouton,0);
						  break;           
     
				 case SDLK_DOWN:  ligne++;
						  if(ligne==3) ligne=1;
                                                  if((*son_bref_on)==1) Mix_PlayChannel(1,bouton,0);
						  break;

				 case SDLK_UP:    ligne--;
						  if(ligne==0) ligne=2;
                                                  if((*son_bref_on)==1) Mix_PlayChannel(1,bouton,0);
						  break;

                             }
         break;

    }
    animation_Menu(menu,ecran);
    if(((*choix)==1)&&(selected2==1))  SDL_BlitSurface(menu->c1,NULL,ecran,NULL); else 
    if(((*choix)==2)&&(selected2==1))  SDL_BlitSurface(menu->c2,NULL,ecran,NULL); else 
    if(((*choix)==1)&&(selected2==2))  SDL_BlitSurface(menu->c3,NULL,ecran,NULL); else 
    if(((*choix)==2)&&(selected2==2))  SDL_BlitSurface(menu->c4,NULL,ecran,NULL); else 
    if(((*choix)==1)&&(selected2==3))  SDL_BlitSurface(menu->c5,NULL,ecran,NULL); else 
    if(((*choix)==2)&&(selected2==3))  SDL_BlitSurface(menu->c6,NULL,ecran,NULL); 
    SDL_Flip(ecran);
    SDL_Delay(100);
   }
}
void MENU_F(MENU *menu,SDL_Surface *ecran,Mix_Music *musique,int *selected,int *choix)
{
Mix_Chunk *bouton;
SDL_Event event;
int continuer=1,selected_button=0,son_bref=0,son_bref_on=1,son_continu_on=1;
//ecran=SDL_SetVideoMode(1200,600,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
init_Menu(menu);
bouton=Mix_LoadWAV("../GAME/menu/button.wav");
musique=Mix_LoadMUS("../GAME/menu/music.mp3");
Mix_PlayMusic(musique,-1);
Mix_VolumeMusic(128);
   while(continuer)
   {  
      SDL_PollEvent(&event);
      switch(event.type)
      {
         case SDL_QUIT: 
                         continuer=0;
                         selected_button=0;
                         break;
         /*case SDL_MOUSEMOTION:   
                                 if((event.motion.x>919)&&(event.motion.x<1069)&&(event.motion.y>414)
                                 &&(event.motion.y<462)) {
							    if(selected_button!=1) son_bref=0;
							    selected_button=1;
							 }

                                 if((event.motion.x>480)&&(event.motion.x<630)&&(event.motion.y>346)
                                 &&(event.motion.y<394)) {
							    if(selected_button!=2) son_bref=0;
							    selected_button=2;
							 }
                                                         
                                 if((event.motion.x>480)&&(event.motion.x<630)&&(event.motion.y>402)
                                 &&(event.motion.y<450)) {	
							    if(selected_button!=3) son_bref=0;						  
							    selected_button=3;
                                                         }

                                 if((event.motion.x>480)&&(event.motion.x<630)&&(event.motion.y>452)
                                 &&(event.motion.y<500)) {
							    if(selected_button!=4) son_bref=0;
							    selected_button=4;
                                                         }

                                 if((event.motion.x>480)&&(event.motion.x<630)&&(event.motion.y>505)
                                 &&(event.motion.y<553)) {
							    if(selected_button!=5) son_bref=0;
							    selected_button=5;
                                                         }

                                 if((event.motion.x>480)&&(event.motion.x<630)&&(event.motion.y>554)
                                 &&(event.motion.y<602)) {
							    if(selected_button!=6) son_bref=0;
						            selected_button=6;
                                                         }
                                 break;*/
						   

         case SDL_KEYDOWN:
                             switch(event.key.keysym.sym)
                             {

				 case SDLK_DOWN:  if(selected_button==7) selected_button=0;
                                                  selected_button++;
						  son_bref=0;
						  break;

				 case SDLK_UP:    if(selected_button==0) selected_button=7;
                                                  selected_button--;
						  son_bref=0;
						  break;

				 case SDLK_RETURN: if((selected_button==2)||(selected_button==3)||(selected_button==6)) continuer=0; 
                                                  if(selected_button==5) {   
								        	f_options(menu,ecran,&son_bref_on,&son_continu_on,bouton);
									 }
                                                  if(selected_button==1) {   
								        	f_choix(menu,ecran,&son_bref_on,bouton,&(*choix));
									 }
                                                  break;

                             }
         break;
      }

   animation_Menu(menu,ecran);
   afficher_boutons_Menu(&(*menu),ecran,selected_button);
if((selected_button!=0)&&(selected_button!=7)&&(son_bref==0)&&(son_bref_on==1)) {
								        	   Mix_PlayChannel(1,bouton,0);
										   son_bref=1;
							                        }
   SDL_Flip(ecran);
   SDL_Delay(100);
   }
   Mix_FreeChunk(bouton);
(*selected)=selected_button;
}
void free_menu(MENU *menu)
{
int i;
for(i=0;i<10;i++)
{
   SDL_FreeSurface(menu->gif[i]);
}
SDL_FreeSurface(menu->b1);SDL_FreeSurface(menu->b2);SDL_FreeSurface(menu->b3);SDL_FreeSurface(menu->b4);SDL_FreeSurface(menu->b5);
SDL_FreeSurface(menu->bs1);SDL_FreeSurface(menu->bs2);SDL_FreeSurface(menu->bs3);SDL_FreeSurface(menu->bs4);SDL_FreeSurface(menu->bs5);
SDL_FreeSurface(menu->choix);SDL_FreeSurface(menu->choixs);
SDL_FreeSurface(menu->op1);
SDL_FreeSurface(menu->op2);
SDL_FreeSurface(menu->op3);
SDL_FreeSurface(menu->op4);
SDL_FreeSurface(menu->boule);
SDL_FreeSurface(menu->c1);
SDL_FreeSurface(menu->c2);
SDL_FreeSurface(menu->c3);
SDL_FreeSurface(menu->c4);
SDL_FreeSurface(menu->c5);
SDL_FreeSurface(menu->c6);
}
