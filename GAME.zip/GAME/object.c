#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL_mixer.h>
#include <SDL/SDL_rotozoom.h>
#include<time.h>
#include"object.h"

void init_obj(OBJECT *obj)
{
obj->portal=NULL;
obj->rotation=NULL;
obj->portal=IMG_Load("portal.png");
obj->pos.x=0;
obj->pos.y=0;
obj->angle = 0;
obj->zoom = 0.39;
obj->sens = 1;
obj->tempsPrecedent=0;
obj->tempsActuel=0;
}
void rotozoom_obj(OBJECT *obj,SDL_Surface *ecran,SDL_Rect *camera)
{

        obj->tempsActuel = SDL_GetTicks();
        if (obj->tempsActuel - obj->tempsPrecedent >50)
        {
            obj->angle += 2;
            obj->tempsPrecedent =obj->tempsActuel;
        }
       

        obj->rotation = rotozoomSurface(obj->portal,obj->angle,obj->zoom, 0);
        obj->pos.x =  3900+850-camera->x - obj->rotation->w / 2;
        obj->pos.y =  500 - obj->rotation->h / 2;
 
        SDL_BlitSurface(obj->rotation,NULL,ecran,&obj->pos);
        SDL_FreeSurface(obj->rotation); 
        if(obj->zoom >= 0.4){obj->sens = 0;}
        else if(obj->zoom <= 0.2){obj->sens = 1;}
 
        if(obj->sens == 0){obj->zoom -= 0.005;}
        else{obj->zoom += 0.005;}
}
void free_obj(OBJECT *obj)
{
SDL_FreeSurface(obj->portal);
}
