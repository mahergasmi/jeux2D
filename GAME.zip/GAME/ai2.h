#ifndef AI2_H__
#define AI2_H__

/*
 * hlavni funkce AI - vyhleda v poli nejlepsi tah a vrati souradnice
 * souradnice policek s nejvyssi prioritou uklada do zasobniku, odkud
 * je nahodne jeden tah vylosovan
 */
TCoord ai2(TGarray, int);

#endif
