#ifndef AI1_H__
#define AI1_H__

//jednoduse hlavni fce, ktera realizuje vyber pozice inteligenci
//prebira dva argumenty, prvni je samotna herni plocha, druhy je
//znak, kterym inteligence hraje - CROSS nebo CIRCLE
TCoord ai1(TGarray, int);

#endif // AI1_H
