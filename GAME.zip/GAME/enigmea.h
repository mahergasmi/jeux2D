#ifndef ENIGMEA_H_INCLUDED
#define ENIGMEA_H_INCLUDED
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "perso.h"
typedef struct
{
    SDL_Surface *ecran;
    SDL_Surface *image;
    SDL_Rect pos;
}enigmea;

void init_enigme2(enigmea *enig);
void afficher_enigme2(SDL_Surface *ecran,enigmea *enig,int *alea);
int solution2(int alea);
int resolution2(int *continuer,int *affiche);
void afficher_resultat2(SDL_Surface *ecran,enigmea *enig,int solution,int resolution,perso *p,vie *v);
void main_enig(SDL_Surface *ecran,enigmea *enig,perso *p,vie *v);
void free_enigme2(enigmea *enig);


#endif // ENIGME_H_INCLUDED

