#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <SDL/SDL.h>
#include "enigme.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include"perso.h"
#include<time.h>

void init_enigme(enigme *enig,int ancienne[])
{
    int i;
    enig->image=NULL;
    enig->texte=NULL;
    enig->police=NULL;
    enig->posim.x=210;
    enig->posim.y=70;
    enig->post.x=290;
    enig->post.y=100;
    for(i=0;i<6;i++)
    {
       ancienne[i]=0;
    }
    enig->image=IMG_Load("../GAME/enigme1/labo.png");
}

void remplir_fichier(char fichier_question[])
{
    FILE *fq=NULL;
    fq=fopen(fichier_question,"w");
    if(fq==NULL) printf("erreur de l'ouverture");
    else
    {
	fprintf(fq,"   Les cellules sanguines sont elles fabriquees dans le coeur?\n As-t-on plus de 100 millions de neurones dans notre cerveau? \nEst-ce que la peau est l'organe le plus lourd du corps humain?\n      As-t-on 20 vertebres dans notre colonnes vertebrale?\n              L'estomac peut-il contenir 5 litres d'eau?\n                              Un adulte as-t-il 34 dents?\n");
	fclose(fq);
    }
}
void afficher_enigme(SDL_Surface *ecran,enigme *enig,int ancienne[],char fichier_question[],int *ligne)
{
   FILE *fq=NULL;
   int i,ici=0,taille=200,l;
   char ch[200];
   SDL_Color couleur={0,255,0};
   do
   {  ici=0;
      l=1+random()%6;
      for(i=0;i<6;i++)
      {
         if(ancienne[i]==l)
                 {
                    ici=1;
                    break;
                 }
      }
   }while(ici==1);
   for(i=0;i<6;i++)
   {
         if(ancienne[i]==0)
                 {
                    ancienne[i]=l;
                    break;
                 }
   }
   if(ancienne[5]!=0) { 
              	         for(i=0;i<6;i++)
              	         {
                            ancienne[i]=0;
              	         }
                      }
   
   enig->police=TTF_OpenFont("../GAME/font/labo.ttf",40);
   fq=fopen(fichier_question,"r");
   if(fq==NULL) printf("erreur de l'ouverture");
    else{ 
           (*ligne)=1;
	   while((fgets(ch,taille,fq)!=NULL)&&(*ligne<l))
	        {
	    	    (*ligne)++;
	        }
           enig->texte=TTF_RenderText_Blended(enig->police,ch,couleur);
	   SDL_BlitSurface(enig->image,NULL,ecran,&(enig->posim));
	   SDL_BlitSurface(enig->texte,NULL,ecran,&(enig->post));
	   SDL_Flip(ecran);
	   fclose(fq);
        }
   
}

int solution(int q)
{
int s=0;
    switch(q)
    {
    case 1:
        s=2;
        break;
    case 2:
        s=1;
        break;
    case 3:
        s=1;
        break;
    case 4:
        s=2;
        break;
    case 5:
        s=2;
        break;
    case 6:
        s=1;
        break;
    }
    return s;
}

int resolution(int *affiche)
{
    SDL_Event event;
    int r=0;
    SDL_PollEvent(&event);
    switch(event.type)
    {

    case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
        case SDLK_a:
            r=1;
	    *affiche=1;
            break;
        case SDLK_z:
            r=2;
	    *affiche=1;
            break;
   
        }
        break;
    }
    return r;
}

void afficher_resultat(SDL_Surface *ecran,enigme *enig,int solution,int resolution,int *score,int *vie)
{
    SDL_Surface *im=NULL;  
    if(resolution==1) im=IMG_Load("../GAME/enigme1/oui.png");
            else im=IMG_Load("../GAME/enigme1/non.png");
    if(solution==resolution)
    {
        SDL_BlitSurface(im,NULL,ecran,&(enig->posim));
        enig->image=IMG_Load("../GAME/enigme1/0.png");
        SDL_BlitSurface(enig->image,NULL,ecran,&(enig->posim));
        SDL_Flip(ecran);
        (*score)+=20;
    }
    else
    {
        SDL_BlitSurface(im,NULL,ecran,&(enig->posim));
        enig->image=IMG_Load("../GAME/enigme1/1.png");
        SDL_BlitSurface(enig->image,NULL,ecran,&(enig->posim));
        SDL_Flip(ecran);
        if((*score)<20) (*vie)++; else (*score)-=20;
    }
    SDL_FreeSurface(im);
}
void enigme_alea(SDL_Surface *ecran,enigme *enig,int ancienne[],char fichier_question[],int *score,int *vie)
{
    SDL_Surface *chance=NULL;
    char ch[10];
    SDL_Color couleur={0,255,0};
    int s,r,continuer=1,affiche=0,nouvelleenig=2,temps_actuel=0,temps_pred=0,ligne=0;
    srand(time(NULL));
   while(nouvelleenig>0)
   {
    if(nouvelleenig==1) {
                           chance=IMG_Load("../GAME/enigme1/chance.png");
                           SDL_BlitSurface(chance,NULL,ecran,&(enig->posim));
                           SDL_Flip(ecran);
                           SDL_Delay(2000);
                        }
    afficher_enigme(ecran,enig,ancienne,"fichier question",&ligne);
    nouvelleenig--;
    s=solution(ligne);
    continuer=1;
    temps_pred=SDL_GetTicks();
    while(continuer)
    {   
   
       temps_actuel=SDL_GetTicks();
       if(temps_actuel-temps_pred>10000)
       {
          if((*score)==0) (*vie)++;
          else
          {
          if(nouvelleenig==1) (*score)-=5;
          if(nouvelleenig==0) (*score)-=10;
          }
          temps_pred=temps_actuel;
          continuer=0;
       }
       else
          { 
          r=resolution(&affiche);
          if(affiche==1) 
          {
             afficher_resultat(ecran,enig,s,r,&(*score),&(*vie));
             SDL_Delay(3000);
             continuer=0;
             nouvelleenig=0;
          }
          }
    }
   } 
SDL_FreeSurface(chance);
}

void ffree(enigme *enig)
{
    TTF_CloseFont(enig->police);
    SDL_FreeSurface(enig->image);
    SDL_FreeSurface(enig->texte);
}
