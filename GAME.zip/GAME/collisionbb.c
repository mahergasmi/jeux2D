#include"perso.h"
#include"ennemi.h"

int collision_attaque(perso *p,ennemi *enn)
{
   if((enn->pos.x>=p->pos.x+100)&&(enn->pos.x-17<=p->pos.x+350)&&(p->pos.y+60>=enn->pos.y))
      return 1;
   else 
      return 0;
}

int collision(SDL_Rect poshero,ennemi *enn)
{
   if(enn->direction==1)
    {
      if(((enn->pos.x)<(poshero.x+75))&&(enn->pos.x>poshero.x)&&(poshero.y+100>=enn->pos.y))
         return 1;
      else
         return 0;
    }
   if(enn->direction==0)
    {
      if(((enn->pos.x)+50>poshero.x)&&(enn->pos.x<poshero.x)&&(poshero.y+100>=enn->pos.y))
         return 1;
      else
         return 0;
    }
}

int collision_attaque2(SDL_Rect poshero,ennemi *enn,int prevd,int prevg)
{
   if((enn->direction==1)&&(prevd==1))
    {
      if(((enn->pos.x)<(poshero.x+150))&&(enn->pos.x>poshero.x+75)&&(poshero.y+50<=enn->pos.y))
         return 1;
      else
         return 0;
    }else
   if((enn->direction==0)&&(prevg==1))
    {
      if(((enn->pos.x)+50>poshero.x)&&(enn->pos.x<poshero.x)&&(poshero.y+150>=enn->pos.y))
         return 1;
      else
         return 0;
    }else if((enn->direction==0)&&(prevg==0)) return 0; else   if((enn->direction==1)&&(prevd==0)) return 0;

}

int collision2(SDL_Rect poshero,ennemi *enn)
{
   if(enn->direction==1)
    {
      if(((enn->pos.x)<(poshero.x+75))&&(enn->pos.x>poshero.x)&&(poshero.y+150>=enn->pos.y))
         return 1;
      else
         return 0;
    }else
   if(enn->direction==0)
    {
      if(((enn->pos.x)+50>poshero.x)&&(enn->pos.x<poshero.x)&&(poshero.y+150>=enn->pos.y))
         return 1;
      else
         return 0;
    }
}



